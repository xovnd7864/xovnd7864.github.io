package org.javaro.lecture;

import java.util.Scanner;
public class Project {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("============태풍은행=============\n"
				+ "사용하실 메뉴를 선택해주세요. \n"+ "1.예금조회 \n2.예금인출\n3.종료");
		int menu = Integer.parseInt(sc.nextLine()); //사용자에게서 입력받은 메뉴값을 저장하는 변수
		int total = 1000000;  //초기계좌잔액 설정
		int password = 0;  //패스워드 변수
		int out = 0;  //출금 금액
		
		while(menu!=3) {
				System.out.println("계좌 비밀번호를 입력해주세요."); 
                //1, 2번 메뉴를 실행하기 위해서는 비밀번호를 올바르게 입력해야 한다.(1,2번 공통)
				password = Integer.parseInt(sc.nextLine());
				
				while(password != 20191346) {
				System.out.println("비밀번호 오류입니다. 다시 입력해주세요.");
				password = Integer.parseInt(sc.nextLine());
                //비밀번호 오류 시 다시 입력받는다.(1,2번 공통)
				}  
				
			if (menu == 1) {
				if (password==20191346) {
					System.out.println("고객님의 계좌잔액은 "+total+"원 입니다.");
					} //사용자가 입력한 비밀번호와 설정해 둔 비밀번호가 동일한 경우 실행된다.
				}
			if (menu == 2) {			
				if(password == 20191346){
					System.out.println("인출할 금액을 입력해주세요.");
					out = Integer.parseInt(sc.nextLine());
					while(out>total) { //인출할 금액이 잔액보다 큰 경우 오류 메시지를 송출
						System.out.println("잔액이 부족합니다. 다시 입력해주세요.");
						System.out.println("인출할 금액을 입력해주세요."); 
                        //인출 금액을 다시 입력받는다.
						out = Integer.parseInt(sc.nextLine());
						} 
					if(out <= total){
						total -= out; 
                        //잔액에서 인출된 금액을 감산한다. 결과적으로 인출을 여러번 실행하면 인출 총액만큼 잔액이 줄어든다.
						System.out.println("출금이 완료되었습니다.");
						}
					}
				}			
			System.out.println("============태풍은행=============\n "
					+ "사용하실 메뉴를 선택해주세요. \n"
					+ "1.예금조회 \n2.예금인출\n3.종료");
			menu = Integer.parseInt(sc.nextLine());
            //1번이나 2번 메뉴 실행 후 다시 메뉴값을 입력받기 위한 장치이다. 
            //사용자가 3.종료를 입력하기 전까지는 계속해서 프로그램이 돌아간다.
		}
		System.out.println("프로그램을 종료합니다.");
        //사용자가 3.종료를 입력하면 메시지 송출과 함께 프로그램이 종료된다.
	}
}